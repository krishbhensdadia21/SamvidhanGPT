from flask import Flask, jsonify, render_template
import pandas as pd

app = Flask(__name__)

# Load the responses from CSV
data = pd.read_csv("micro.csv")
inputs = data['Input'].str.strip().str.lower().values  # Strip and convert to lowercase
responses = data['Response'].values

# Create a response dictionary
response_dict = dict(zip(inputs, responses))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get-response/<user_input>', methods=['GET'])
def get_response(user_input):
    user_input = user_input.strip().lower()  # Remove whitespace and make lowercase
    print(f"User Input: '{user_input}'")  # Log the user input
    response = response_dict.get(user_input, "Please ask another question.")
    print(f"Response: '{response}'")  # Log the response
    return jsonify({"response": response})

if __name__ == '__main__':
    app.run(debug=True)